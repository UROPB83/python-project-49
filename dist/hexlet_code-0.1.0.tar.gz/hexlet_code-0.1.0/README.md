### Hexlet tests and linter status:
[![Actions Status](https://github.com/UROPB83/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/UROPB83/python-project-49/actions)
brain-even:https://asciinema.org/connect/bf52c79c-02de-4bc2-964d-966b57150c25
brain-calc:https://asciinema.org/connect/bf52c79c-02de-4bc2-964d-966b57150c25 
brain-gcd:https://asciinema.org/connect/bf52c79c-02de-4bc2-964d-966b57150c25
brain-progression:https://asciinema.org/connect/bf52c79c-02de-4bc2-964d-966b57150c25
brain-prime:https://asciinema.org/connect/bf52c79c-02de-4bc2-964d-966b57150c25
[![Maintainability](https://api.codeclimate.com/v1/badges/d811a7665f5c277b12cd/maintainability)](https://codeclimate.com/github/UROPB83/python-project-49/maintainability)
