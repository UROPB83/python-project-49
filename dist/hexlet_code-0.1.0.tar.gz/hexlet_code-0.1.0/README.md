### Hexlet tests and linter status:
[![Actions Status](https://github.com/UROPB83/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/UROPB83/python-project-49/actions)
brain-even:https://asciinema.org/connect/bf52c79c-02de-4bc2-964d-966b57150c25
brain-calc:https://asciinema.org/connect/bf52c79c-02de-4bc2-964d-966b57150c25 
brain-gcd:https://asciinema.org/connect/bf52c79c-02de-4bc2-964d-966b57150c25
brain-progression:https://asciinema.org/connect/bf52c79c-02de-4bc2-964d-966b57150c25